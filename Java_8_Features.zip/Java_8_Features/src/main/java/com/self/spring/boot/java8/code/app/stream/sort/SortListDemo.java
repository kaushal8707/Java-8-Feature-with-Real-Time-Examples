package com.self.spring.boot.java8.code.app.stream.sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SortListDemo {
	public static void main(String[] args) {
		List<Integer> list=new ArrayList<Integer>();
		list.add(8);
		list.add(3);
		list.add(12);
		list.add(4);
		
		//traditional approach
		Collections.sort(list); //ASCENDING
		Collections.reverse(list); //DESCENDING
		System.out.println(list);	
		
		list.stream().sorted().forEach(a->System.out.println(a));  //ascending
		list.stream().sorted(Comparator.reverseOrder()).forEach(a->System.out.println(a)); //reverse order
		
	}
}
