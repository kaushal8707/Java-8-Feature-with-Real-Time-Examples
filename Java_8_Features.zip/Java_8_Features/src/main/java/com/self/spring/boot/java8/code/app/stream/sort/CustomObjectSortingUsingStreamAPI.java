package com.self.spring.boot.java8.code.app.stream.sort;

import java.util.Comparator;
import java.util.List;

import com.self.spring.boot.java8.code.app.stream.api.example.DataBase;
import com.self.spring.boot.java8.code.app.stream.api.example.Employee;

public class CustomObjectSortingUsingStreamAPI {
	public static void main(String[] args) {

		List<Employee> list=DataBase.getEmployee();
		//using comparator in stream api
		list.stream().sorted((o1,o2)-> (int) (o2.getSalary()-o1.getSalary())).forEach(System.out::println);
		
		//using stream api
		list.stream().sorted(Comparator.comparing(emp->emp.getSalary())).forEach(System.out::println);
		
		//using Method Reference
		list.stream().sorted(Comparator.comparing(Employee :: getName)).forEach(System.out::println);
	}
}
