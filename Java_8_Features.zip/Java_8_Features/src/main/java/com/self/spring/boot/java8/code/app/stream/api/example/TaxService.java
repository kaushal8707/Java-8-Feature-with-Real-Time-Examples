package com.self.spring.boot.java8.code.app.stream.api.example;

import java.util.List;
import java.util.stream.Collectors;

//Taxable whose salary more than 5 lakhs
public class TaxService
{
	public static List<Employee> evaluateTaxUsers(String input)
	{
		 if(input.equalsIgnoreCase("tax"))
		 {
			return DataBase.getEmployee().stream().filter(emp->emp.getSalary()>500000)
					.collect(Collectors.toList());
		 }else {
				return DataBase.getEmployee().stream().filter(emp->emp.getSalary()<=500000)
						.collect(Collectors.toList());
		 }
		 
		 //Using Ternary Operator
//		return input.equalsIgnoreCase("tax")
//		 ? DataBase.getEmployee().stream().filter(emp->emp.getSalary()>500000).collect(Collectors.toList())
//		 : DataBase.getEmployee().stream().filter(emp->emp.getSalary()<=500000)
//					.collect(Collectors.toList());
	}
	public static void main(String[] args) {
		System.out.println(evaluateTaxUsers("tax"));
	}

}
