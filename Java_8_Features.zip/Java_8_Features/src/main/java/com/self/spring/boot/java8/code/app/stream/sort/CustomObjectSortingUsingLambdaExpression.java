package com.self.spring.boot.java8.code.app.stream.sort;

import java.util.Collections;
import java.util.List;
import com.self.spring.boot.java8.code.app.stream.api.example.DataBase;
import com.self.spring.boot.java8.code.app.stream.api.example.Employee;

public class CustomObjectSortingUsingLambdaExpression {
	public static void main(String[] args) {
		List<Employee> employees=DataBase.getEmployee();
		Collections.sort(employees, (o1,o2)->  (int) (o2.getSalary() - o1.getSalary()));
		
		System.out.println(employees);
		
	}
}
