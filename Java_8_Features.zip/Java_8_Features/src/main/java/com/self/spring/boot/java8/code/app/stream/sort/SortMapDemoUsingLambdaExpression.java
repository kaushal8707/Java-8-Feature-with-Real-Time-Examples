package com.self.spring.boot.java8.code.app.stream.sort;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class SortMapDemoUsingLambdaExpression {
	public static void main(String[] args) {
		Map<String,Integer> map=new HashMap<>();
		map.put("four", 4);
		map.put("eight", 8);
		map.put("ten", 10);
		map.put("two", 2);
		
		List<Entry<String,Integer>>list=new ArrayList<>(map.entrySet());
		Collections.sort(list, (o1,o2) -> o1.getValue().compareTo(o2.getValue()));
		
		list.forEach(entry-> System.out.println(entry.getKey()+"   :  "+entry.getValue()));	
	}
}
