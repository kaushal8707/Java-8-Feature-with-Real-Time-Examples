package com.self.spring.boot.java8.code.app.stream.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FilterDemo {
	public static void main(String[] args) {
		List<String> list=new ArrayList<String>();
		list.add("Murrit");
		list.add("john");
		list.add("piter");
		list.add("marek");
		list.add("mac");
		list.stream().filter(t->t.startsWith("m")).forEach(a->System.out.println(a));
		
		//get even key and value
		Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(1,"a");
		map.put(2,"b");
		map.put(3,"c");
		map.put(4,"d");
		map.entrySet().stream().filter(t->t.getKey()%2==0).forEach(a->System.out.println(a));
	}
}
