package com.self.spring.boot.java8.code.app.pre.functional.demo;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class SupplierDemo{
	
	//traditional approach
//	@Override
//	public String get() {
//		return "Hi Java Programmer !!";
//	}
	
	public static void main(String[] args) {
	Supplier<String> supplier = ()->  "Hi Java Programmer !!";
	
	List<String> list=Arrays.asList(); 
	System.out.println(list.stream().findAny().orElseGet(supplier));
//	System.out.println(supplier.get()); 
		
	}
}
