package com.self.spring.boot.develop.app;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonParseServiceApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(JsonParseServiceApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
        //JSON File to Object - jackson Data Binding
		//JSON_File_to_Object_Jackson_Data_Binding.jsonFileToObjectUsingJacksonDataBinding();
        
        //Java Object to JSON File
		//Java_Object_to_JSON_File.java_Object_to_JSON_File();
       
		//JSON File to Map - Simple Data Binding
		//JSON_File_to_Map_Simple_Data_Binding.jSON_File_to_Map_Simple_Data_Binding();
        
		JSON_File_into_a_Tree_Model.jSON_File_into_a_Tree_Model();
        
	}}
