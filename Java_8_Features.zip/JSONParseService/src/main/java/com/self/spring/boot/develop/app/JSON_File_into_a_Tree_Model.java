package com.self.spring.boot.develop.app;

import java.io.File;
import java.nio.file.Files;

import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSON_File_into_a_Tree_Model 
{
	public static void jSON_File_into_a_Tree_Model() throws Exception 
	{
		//create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

        File resource = new ClassPathResource("data/customer.json").getFile(); 
        String message = new String(Files.readAllBytes(resource.toPath())); 
        
		//read customer.json file into tree model
		JsonNode rootNode = objectMapper.readTree(message); 

		//read name and phone nodes
		System.out.println("Customer Name: " + rootNode.path("name").asText());
		System.out.println("Customer Phone: " + rootNode.path("phone").asText());
		System.out.println("Customer Age: " + rootNode.path("age").asInt());
		System.out.println("Customer City: " + rootNode.path("address").path("city").asText());
		System.out.println("Customer Project: " + rootNode.path("projects").get(0).asText());
		System.out.println("Customer Source: " + rootNode.path("profileInfo").path("source").asText());
		rootNode.path("paymentMethods").forEach(a->System.out.println(a+" , "));
		
	}

}
