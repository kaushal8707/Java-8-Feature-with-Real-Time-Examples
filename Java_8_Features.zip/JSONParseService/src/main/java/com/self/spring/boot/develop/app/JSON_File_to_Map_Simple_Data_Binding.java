package com.self.spring.boot.develop.app;
import java.io.File;
import java.nio.file.Files;
import java.util.Map;
import org.springframework.core.io.ClassPathResource;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSON_File_to_Map_Simple_Data_Binding 
{
	public static void jSON_File_to_Map_Simple_Data_Binding() throws Exception 
	{
		//create ObjectMapper instance
		ObjectMapper objectMapper = new ObjectMapper();

		//convert json file to map
        File resource = new ClassPathResource("data/customer.json").getFile(); 
        String message = new String(Files.readAllBytes(resource.toPath())); 

        Map<?, ?> map= objectMapper.readValue(message, Map.class);

		//iterate over map entries and print to console
		for (Map.Entry<?, ?> entry : map.entrySet()) {
		    System.out.println(entry.getKey() + "=" + entry.getValue());
		}

	}
}
