package com.self.spring.boot.develop.app;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.self.spring.boot.develop.app.model.Address;
import com.self.spring.boot.develop.app.model.Customer;

public class Java_Object_to_JSON_File 
{
	public static void java_Object_to_JSON_File() throws Exception 
	{
		 //create ObjectMapper instance
        ObjectMapper objectMapper = new ObjectMapper();

        //create a customer object
        Customer customerObj = new Customer();
        customerObj.setId(567L);
        customerObj.setName("Maria Kovosi");
        customerObj.setEmail("kk430@example.com");
        customerObj.setPhone("+12 785 4895 321");
        customerObj.setAge(29);
        customerObj.setProjects(new String[]{"Path Finder App", "Push Notifications"});

        Address address = new Address();
        address.setStreet("Karchstr.");
        address.setCity("Hanover");
        address.setZipcode(66525);
        address.setCountry("Germany");
        customerObj.setAddress(address);

        List<String> paymentMethods = new ArrayList<>();
        paymentMethods.add("PayPal");
        paymentMethods.add("SOFORT");
        customerObj.setPaymentMethods(paymentMethods);

        Map<String, Object> info = new HashMap<>();
        info.put("gender", "female");
        info.put("married", "No");
        info.put("income", "120,000 EURO");
        info.put("source", "Google Search");
        customerObj.setProfileInfo(info);

        //configure objectMapper for pretty input
        objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        File f=new File("C:\\Users\\kaukumar3\\Documents\\workspace-spring-tool-suite-4-4.14.1.RELEASE\\JSONParseService\\src\\main\\resources\\data\\customer2.json");
        if(!f.exists())
        {
        	f.mkdirs();
        }
        
        objectMapper.writeValue(f, customerObj);
        System.out.println("customer2.json content written Done . . .");
	}
}
