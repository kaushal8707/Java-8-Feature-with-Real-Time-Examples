package com.self.spring.boot.develop.app;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.util.stream.Collectors;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.ResourceUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.self.spring.boot.develop.app.model.Customer;

public class JSON_File_to_Object_Jackson_Data_Binding
{
	public static void jsonFileToObjectUsingJacksonDataBinding() throws Exception 
	{
		 //create ObjectMapper instance
        ObjectMapper mapper = new ObjectMapper();        
        
        //Way 1 to read json from json file
        InputStream resource = new ClassPathResource("data/customer.json").getInputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(resource));
        String message1 = reader.lines().collect(Collectors.joining("\n"));
        	         
        //Way 2 to read json from json file
        File resource2 = new ClassPathResource("data/customer.json").getFile(); 
        String message2 = new String(Files.readAllBytes(resource2.toPath())); 
        
        //Way 3 to read json from json file
        File file=ResourceUtils.getFile("classpath:data/customer.json");
        String message3=new String(Files.readAllBytes(file.toPath()));
        
        
        
        //read json file and convert to customer object
        Customer customer1 = mapper.readValue(message1, Customer.class);
        Customer customer2 = mapper.readValue(message2, Customer.class);
        Customer customer3 = mapper.readValue(message3, Customer.class);

        //print customer details
        System.out.println(customer1);
        System.out.println(customer2);
        System.out.println(customer3);
        
        
	}

}
