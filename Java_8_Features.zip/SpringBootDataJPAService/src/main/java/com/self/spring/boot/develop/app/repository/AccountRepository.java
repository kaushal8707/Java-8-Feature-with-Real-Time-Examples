package com.self.spring.boot.develop.app.repository;

import org.springframework.data.repository.CrudRepository;
import java.util.*;
import com.self.spring.boot.develop.app.entity.Account;
import com.self.spring.boot.develop.app.entity.AccountId;

public interface AccountRepository extends CrudRepository<Account, AccountId> {

	List<Account> findByAccounttype(String accountType);
	
}
