package com.self.spring.boot.develop.app.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;
import com.self.spring.boot.develop.app.entity.Movie;

public interface MovieRepository extends CrudRepository<Movie, Long>,
		JpaSpecificationExecutor<Movie> 
{
	

}
