package com.self.spring.boot.develop.app.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.self.spring.boot.develop.app.entity.GCMRecord;

@Repository
public interface GCMRepository extends JpaRepository<GCMRecord, Integer>{
	
	List<GCMRecord> findByName(String name);
	GCMRecord findByEmail(String email);

}