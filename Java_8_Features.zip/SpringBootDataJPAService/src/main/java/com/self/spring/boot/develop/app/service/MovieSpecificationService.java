package com.self.spring.boot.develop.app.service;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import com.self.spring.boot.develop.app.entity.Movie;
import com.self.spring.boot.develop.app.repository.MovieRepository;
import com.self.spring.boot.develop.app.repository.specs.MovieSpecification;
import com.self.spring.boot.develop.app.repository.specs.SearchCriteria;
import com.self.spring.boot.develop.app.repository.specs.SearchOperation;

@Service
public class MovieSpecificationService 
{
	private static final Logger logger=LoggerFactory.getLogger(MovieSpecificationService.class);
	@Autowired
	MovieRepository movieRepository;
	
    // create new movies
	public void saveAllMovieRecords()
	{
        movieRepository.saveAll(Arrays.asList(
                new Movie("Troy", "Drama", 7.2, 196, 2004),
                new Movie("The Godfather", "Crime", 9.2, 178, 1972),
                new Movie("Invictus", "Sport", 7.3, 135, 2009),
                new Movie("Black Panther", "Action", 7.3, 135, 2018),
                new Movie("Joker", "Drama", 8.9, 122, 2018),
                new Movie("Iron Man", "Action", 8.9, 126, 2008)
        ));

        logger.info("saved all movies record");


	}

    // search movies by `genre`
	public void searchMoviesByGenre() {
		 MovieSpecification msGenre=new MovieSpecification();
		 msGenre.add(new SearchCriteria("genre", "Action", SearchOperation.EQUAL));
		 List<Movie> msGenreList=movieRepository.findAll(msGenre);
		 msGenreList.forEach(System.out::println); 
	}

	
    // search movies by `title` and `rating` > 7
	public void searchMovieByTitleAndRating() {
	MovieSpecification msTitleRating=new MovieSpecification();
	msTitleRating.add(new SearchCriteria("title", "god", SearchOperation.MATCH));
	msTitleRating.add(new SearchCriteria("rating", 7, SearchOperation.GREATER_THAN));
	List<Movie> msTitleRatingList=movieRepository.findAll(msTitleRating);
	msTitleRatingList.forEach(System.out::println);	
	}

    // search movies by release year < 2010 and rating > 8
	public void searchMoviebyReleaseYearAndRating()
	{
		MovieSpecification msReleaseRating=new MovieSpecification();
		msReleaseRating.add(new SearchCriteria("releaseyear", "2010", SearchOperation.LESS_THAN));
		msReleaseRating.add(new SearchCriteria("rating", 8, SearchOperation.GREATER_THAN));
		List<Movie> msReleaseRatingList=movieRepository.findAll(msReleaseRating);
		msReleaseRatingList.forEach(System.out::println);
	} 
	
    // search movies by watch time >= 150 and sort by `title`
	public void searchMoviebyWatchTime()
	{
        MovieSpecification msWatchTime = new MovieSpecification();
        msWatchTime.add(new SearchCriteria("watchtime", 150, SearchOperation.GREATER_THAN_EQUAL));
        List<Movie> msWatchTimeList = movieRepository.findAll(msWatchTime, Sort.by("title"));
        msWatchTimeList.forEach(System.out::println);
	}

    // search movies by `title` <> 'white' and paginate results
	public void searchMovieByTitlePageResult()
	{
		MovieSpecification msTitle=new MovieSpecification();
		msTitle.add(new SearchCriteria("title","WHITE",SearchOperation.NOT_EQUAL));
		Pageable pageable=PageRequest.of(0, 4, Sort.by("releaseyear").descending());
		Page<Movie> msTitleList =movieRepository.findAll(msTitle, pageable);
		msTitleList.forEach(System.out::println); 
	}
	
	//OR and AND Search 
	public void searchMovieByOR_AND()
	{
		MovieSpecification msReleaseRating=new MovieSpecification();
		msReleaseRating.add(new SearchCriteria("releaseyear", "2010", SearchOperation.LESS_THAN));
		msReleaseRating.add(new SearchCriteria("rating", 8, SearchOperation.GREATER_THAN));
		
		MovieSpecification msTitle=new MovieSpecification();
		msTitle.add(new SearchCriteria("title","WHITE",SearchOperation.NOT_EQUAL));
		
		// combine using `AND` operator
		List<Movie> moviesAND = movieRepository.findAll(Specification.where(msTitle).and(msReleaseRating));
		moviesAND.forEach(System.out::println);
		System.out.println(">>>>>>>>>");
		// combine using `OR` operator
		List<Movie> moviesOR = movieRepository.findAll(Specification.where(msTitle).or(msReleaseRating));
		moviesOR.forEach(System.out::println);

	}





} 
