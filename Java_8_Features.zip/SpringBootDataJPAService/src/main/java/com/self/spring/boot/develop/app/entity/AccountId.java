package com.self.spring.boot.develop.app.entity;

import java.io.Serializable;
import java.util.Objects;

public class AccountId implements Serializable {
	private String accountnumber;
    private String accounttype;

    public AccountId() {
    }

    public AccountId(String accountNumber, String accountType) {
        this.accountnumber = accountNumber;
        this.accounttype = accountType;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountId accountId = (AccountId) o;
        return accountnumber.equals(accountId.accountnumber) &&
        		accounttype.equals(accountId.accounttype);
    }

    public int hashCode() {
        return Objects.hash(accountnumber, accounttype);
    }

}
