package com.self.spring.boot.develop.app.service;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.self.spring.boot.develop.app.entity.Account;
import com.self.spring.boot.develop.app.entity.AccountId;
import com.self.spring.boot.develop.app.repository.AccountRepository;

@Service
public class AccountService 
{
	@Autowired
	AccountRepository accountRepository;
	
	Logger log=LoggerFactory.getLogger(AccountService.class);

	// ======= `@IdClass` Annotation =======

    // create new accounts
	public void createAccount()
	{
	    accountRepository.save(new Account("458666", "Checking", 4588));
	    accountRepository.save(new Account("458689", "Checking", 2500));
	    accountRepository.save(new Account("424265", "Saving", 100000));
	    log.info("account created");
	}
	
    // fetch accounts by a given type
	public void fetchAccount()
	{
	    List<Account> accounts = accountRepository.findByAccounttype("Checking");
	    accounts.forEach(System.out::println);
	}
	
    // fetch account by composite key
	public void fetchByCompositeKey()
	{
	    Optional<Account> account = accountRepository.findById(new AccountId("424265", "aving"));
	    account.ifPresent(System.out::println);
	}



}
