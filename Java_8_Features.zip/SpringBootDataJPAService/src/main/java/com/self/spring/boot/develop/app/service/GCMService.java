package com.self.spring.boot.develop.app.service;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.self.spring.boot.develop.app.entity.GCMRecord;
import com.self.spring.boot.develop.app.repository.GCMRepository;

@Service
public class GCMService {
	private static final Logger logger=LoggerFactory.getLogger(GCMService.class);
	@Autowired
	GCMRepository gcmRepository;
	
	public void userStored()

	{
		//it stores 10 records in one shots
		for(int i=1;i<=10;i++)
		{
			GCMRecord gcmRecord=new GCMRecord();
			gcmRecord.setName("Random_"+i);
			gcmRecord.setEmail("Random_Email_"+i);
			gcmRepository.save(gcmRecord);
		}
		
		///it stores only 1 record in one shot because same object its overriding...so result would be Random_Temp_10---
		//Random_Email_Temp_10 because its not creating a new instance to insert object not getting detached after persisting
		
		GCMRecord gcmRecord1=new GCMRecord();
		for(int i=1;i<=10;i++)
		{
			gcmRecord1.setName("Random_Temp_"+i);
			gcmRecord1.setEmail("Random_Email_Temp_"+i);
			gcmRepository.save(gcmRecord1);
		}
		logger.info("Data Inserted to DB");		
	}

    // fetch user by Name
	public void fetchUserByName(String name)
	{
		List<GCMRecord> records=gcmRepository.findByName(name);
        logger.info("GCM Record found with findByName('Random_3'):");
		records.forEach(l->logger.info(name));
		logger.info("List of GCM Record - "+records); 

	}
	// fetch user by Email
	public void fetchUserByEmail(String email)
	{
		GCMRecord record=gcmRepository.findByEmail(email);
        logger.info("GCM Record found with findByEmail('Random_Email_4'):");
		logger.info("GCM Record - "+record); 
	}
	
	//fetch All Users
	public void fetchAllUsers()
	{
		List<GCMRecord> list=gcmRepository.findAll();
		list.forEach(System.out::println);
		
	}
    // fetch user by id
	public void fetchUserById(int id)
	{
		Optional<GCMRecord> optional=gcmRepository.findById(15);
		if(optional.isPresent())
		{
			GCMRecord record=optional.get();
			logger.info(" "+record);
		}
        logger.info("GCM Record found with findById('15'):");
	}
	// delete user by id
		public void deleteUserById(int id)
		{
			gcmRepository.deleteById(id);
			
	        logger.info("GCM Record deleted with deleteById('13'):");
		}
	
	// delete all users	
		public void deleteAllUsers()
		{
			gcmRepository.deleteAll();
			
	        logger.info("GCM All Records got deleted with deleteAll");
		}
		
    // confirm users deletion
		public void findNumberOfUsersInDB()
		{
			long count=gcmRepository.count();
			logger.info("Total records avail in DB : "+count); 
			
		}
}
