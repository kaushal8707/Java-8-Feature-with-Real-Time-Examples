package com.self.spring.boot.develop.app.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.self.spring.boot.develop.app.entity.Employee;
import com.self.spring.boot.develop.app.entity.EmployeeId;
import com.self.spring.boot.develop.app.repository.EmployeeRepository;

@Service
public class EmployeeService 
{
	
   Logger log=LoggerFactory.getLogger(EmployeeService.class);
	
   @Autowired
   EmployeeRepository employeeRepository;

public void createEmployees() {
    employeeRepository.save(new Employee(new EmployeeId(100L, 10L),
            "John Doe", "john@example.com", "123456"));
    employeeRepository.save(new Employee(new EmployeeId(101L, 20L),
            "Emma Ali", "emma@example.com", "654321"));	
    
    log.info("employee record inserted");
    
}

public void findRecordByEmployeeIdDepartmentId() 
{
    List<Employee> employees = employeeRepository.findByEmployeeIdDepartmentId(20L);
    employees.forEach(System.out::println);	
}

public void findEmployeeByCompositeKey()
{
    Optional<Employee> employee = employeeRepository.findById(new EmployeeId(100L, 10L));
    employee.ifPresent(System.out::println);	
}
   
   
}
