package com.self.spring.boot.develop.app.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.self.spring.boot.develop.app.entity.Employee;
import com.self.spring.boot.develop.app.entity.EmployeeId;

public interface EmployeeRepository extends CrudRepository<Employee, EmployeeId> {

	//query to fetch all employees by a given department ID:
	List<Employee> findByEmployeeIdDepartmentId(Long departmentId);
}
