package com.self.spring.boot.develop.app.entity;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "account")
@IdClass(AccountId.class) 
public class Account implements  Serializable
{
   @Id
   private String accountnumber;
   @Id
   private String accounttype;
   private double balance;
   public Account() {}
   
   public Account(String accountNumber, String accountType, double balance) {
	super();
	this.accountnumber = accountNumber;
	this.accounttype = accountType;
	this.balance = balance;
}

public String getAccountNumber() {
	return accountnumber;
}

public void setAccountNumber(String accountNumber) {
	this.accountnumber = accountNumber;
}

public String getAccountType() {
	return accounttype;
}

public void setAccountType(String accountType) {
	this.accounttype = accountType;
}

public double getBalance() {
	return balance;
}

public void setBalance(double balance) {
	this.balance = balance;
}

@Override
public String toString() {
	return "Account [accountNumber=" + accountnumber + ", accountType=" + accounttype + ", balance=" + balance + "]";
}
   
}
