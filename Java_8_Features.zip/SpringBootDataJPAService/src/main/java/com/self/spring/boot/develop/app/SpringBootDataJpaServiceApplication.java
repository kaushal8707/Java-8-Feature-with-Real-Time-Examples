package com.self.spring.boot.develop.app;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.self.spring.boot.develop.app.service.AccountService;
import com.self.spring.boot.develop.app.service.EmployeeService;
import com.self.spring.boot.develop.app.service.GCMService;
import com.self.spring.boot.develop.app.service.MovieSpecificationService;
import com.self.spring.boot.develop.app.service.mapping.OneToOneServiceApplication;

@SpringBootApplication
@EnableAutoConfiguration
@EntityScan("com.self.spring.boot.develop.app.entity")
@ComponentScan({"com.self.spring.boot.develop.app.service"})
@EnableJpaRepositories("com.self.spring.boot.develop.app.repository")

public class SpringBootDataJpaServiceApplication implements CommandLineRunner{

	@Autowired
	GCMService gcmService;
	
	@Autowired
	MovieSpecificationService movieSpecificationService;
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	OneToOneServiceApplication oneToOneServiceApplication;
	
	private static final Logger logger=LoggerFactory.getLogger(SpringBootDataJpaServiceApplication.class);
	public static void main(String[] args) 
	{
		SpringApplication
		.run(SpringBootDataJpaServiceApplication.class, args);
	}
	

	@Override
	public void run(String... args) throws Exception {
		
		//Spring Data JPA Examples
		
		//gcmService.userStored();
//----		gcmService.fetchUserByName("Random_3");
//----		gcmService.fetchUserByEmail("Random_Email_4");
//----		gcmService.fetchAllUsers();
//----		gcmService.fetchUserById(15);
//----		gcmService.deleteUserById(14);
		//gcmService.deleteAllUsers();
        // confirm users deletion
//----		gcmService.findNumberOfUsersInDB();
		
		
		//Dynamic Queries with Spring Data JPA Specifications
//---		movieSpecificationService.saveAllMovieRecords();
		
		// search movies by `genre`
//----       movieSpecificationService.searchMoviesByGenre();

       // search movies by `title` and `rating` > 7
//----       movieSpecificationService.searchMovieByTitleAndRating();
		
       // search movies by release year < 2010 and rating > 8
//----       movieSpecificationService.searchMoviebyReleaseYearAndRating();
       
       // search movies by watch time >= 150 and sort by `title`
//----   	   movieSpecificationService.searchMoviebyWatchTime();
//----   	   System.out.println("----------------"); 
       // search movies by `title` <> 'white' and paginate results
//----   	   movieSpecificationService.searchMovieByTitlePageResult();
//----   	   System.out.println("=======================");
	   	//OR and AND Search 
//----	    movieSpecificationService.searchMovieByOR_AND();
	    
	    
	    //------------------------------------------------------
	    
	    //Composite Primary Key Mapping
		// ======= `@IdClass` Annotation =======

	    
//---	    accountService.createAccount();
        // fetch accounts by a given type
//--	    accountService.fetchAccount();
	    
	    // fetch account by composite key
//--		  accountService.fetchByCompositeKey();	    
	    
	  
		// ======= `@EmbeddedId` Annotation =======

        // create new employees
//--		employeeService.createEmployees();

        // fetch employees by a given department id
//--		employeeService.findRecordByEmployeeIdDepartmentId();

        // fetch employee by composite key
//--			employeeService.findEmployeeByCompositeKey();

		
		
		
//							Hibernate-Mapping
//		-----------------------------------------------------
		
		oneToOneServiceApplication.OneToOneMapping();	
		
		
		
		
		
		
		
		
	}
	
	

}
