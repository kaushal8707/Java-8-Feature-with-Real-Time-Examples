package com.self.spring.boot.develop.app.service.mapping;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.self.spring.boot.develop.app.entity.mapping.Address;
import com.self.spring.boot.develop.app.entity.mapping.User;
import com.self.spring.boot.develop.app.repository.mapping.UserRepository;

@Service
public class OneToOneServiceApplication {

	@Autowired
	UserRepository userRepository;
	
   public void OneToOneMapping()
   {
	   // create a user instance
	    User user = new User("John Doe", "john.doe@example.com", "1234abcd");

	    // create an address instance
	    Address address = new Address("Lake View 321", "Berlin", "Berlin","95781", "DE");
	    // set child reference
	    address.setUser(user);

	    // set parent reference
	    user.setAddress(address); 
	    
        // save the parent
        // which will save the child (address) as well
        userRepository.save(user);

   }

    
    
}
