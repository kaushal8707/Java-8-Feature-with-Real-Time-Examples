package com.self.spring.boot.develop.app.repository.mapping;

import org.springframework.data.repository.CrudRepository;

import com.self.spring.boot.develop.app.entity.mapping.User;

public interface UserRepository extends CrudRepository<User, Long>{

}
