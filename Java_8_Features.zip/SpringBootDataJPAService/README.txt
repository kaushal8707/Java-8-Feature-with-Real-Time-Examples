Difference Between Composite Key ( @IdClass and the @EmbeddedId annotations )
-----------------------------------------------------------------------------

In the main application class, we used both AccountRepository and EmployeeRepository repositories to test our implementation of a composite primary key with @IdClass and @EmbeddedId.
The next step is to run the application to see the output. For Gradle, execute the following command to start the application:
$ ./gradlew bootRun
For Maven, type the following command to launch the application:
$ ./mvnw spring-boot:run
When the application starts, you should see the following output printed on the console:
Account{accountNumber='458666', accountType='Checking', balance=4588.0}
Account{accountNumber='458689', accountType='Checking', balance=2500.0}
Account{accountNumber='424265', accountType='Saving', balance=100000.0}
Employee{employeeId=EmployeeId{employeeId=101, departmentId=20}, name='Emma Ali', email='emma@example.com', phoneNumber='654321'}
Employee{employeeId=EmployeeId{employeeId=100, departmentId=10}, name='John Doe', email='john@example.com', phoneNumber='123456'}
@IdClass vs @EmbeddedId
The main difference between @IdClass and @EmbeddedId annotations is that with @IdClass, you need to specify the primary key columns twice � once in the composite primary key class and then again in the entity class with the @Id annotation.
The @EmbeddedId annotation is more verbose than @IdClass as you can access the entire primary key object using the field access method. This also gives a clear notion of the fields that are part of the composite key because they are all aggregated in a class that is only accessible through a field access method.
Another difference between @IdClass and @EmbeddedId is when it comes to creating custom JPQL queries.
For example, with @IdClass, the query is a little simpler:
SELECT a.accountType FROM Account a
With @EmbeddedId, you have to write more text for a similar query:
SELECT e.employeeId.departmentId FROM Employee e
The @IdClass annotation can be a preferred choice over @EmbeddedId in situations where the composite primary key class is not accessible or comes in from another module or legacy code. For such scenarios, where you cannot modify the composite key class, the @IdClass annotation is the only way-out.

**************************************

the differences between the @IdClass and the @EmbeddedId annotations. 
If we need to access parts of the composite key, just use @IdClass, 
but for scenarios where you frequently use the composite key as an object, 
@EmbeddedId should be preferred.



One to One Mapping
===================

Both User and Address classes are annotated with Entity to indicate that they are JPA entities.
The @Table annotation is used to specify the name of the database table that should be mapped to this entity.
The id attributes are annotated with both @Id and @GeneratedValue annotations. The former annotation indicates that they are the primary keys of the entities. The latter annotation defines the primary key generation strategy. In the above case, we have declared that the primary key should be an AUTO INCREMENT field.
@OneToOne Annotation
In Spring Data JPA, a one-to-one relationship between two entities is declared by using the @OneToOne annotation. It accepts the following parameters:
�	fetch � Defines a strategy for fetching data from the database. By default, it is EAGER which means that the data must be eagerly fetched. We have set it to LAZY to fetch the entities lazily from the database.
�	cascade � Defines a set of cascadable operations that are applied to the associated entity. CascadeType.ALL means to apply all cascading operations to the related entity. Cascading operations are applied when you delete or update the parent entity.
�	mappedBy � Defines the entity that owns the relationship which is the Address entity in our case.
�	optional � Defines whether the relationship is optional. If set to false then a non-null relationship must always exist.
In a bidirectional relationship, we have to specify the @OneToOne annotation in both entities. But only one entity is the owner of the association. Usually, the child entity is one that owns the relationship and the parent entity is the inverse side of the relationship.
@JoinColumn Annotation
The @JoinColumn annotation is used to specify the foreign key column in the owner of the relationship. The inverse-side of the relationship sets the @OneToOne's mappedBy parameter to indicate that the relationship is mapped by the other entity.
The @JoinColumn accepts the following two important parameters, among others:
�	name � Defines the name of the foreign key column.
�	nullable � Defines whether the foreign key column is nullable. By default, it is true.


